# Local machine configuration.

# CPU speed in clock cycles per second
CPU_SPEED = 2.2e9

