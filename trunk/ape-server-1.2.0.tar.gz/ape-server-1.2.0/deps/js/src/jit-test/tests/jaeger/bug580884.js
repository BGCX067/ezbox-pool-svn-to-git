// |jit-test| error: ReferenceError
for (let a in [0])
a = e
for (let a in [0])
(function () {
    a
})

