options("strict", "werror");

var o = {};

// Don't throw here.
if (o.a)
    x = true;
