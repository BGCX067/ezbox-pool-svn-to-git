// don't assert
new(function() {
    #1#
})

