
NaN = 4;
undefined = 5;
Infinity = 6;

assertEq(isNaN(NaN), true);
assertEq(Infinity > 100, true);
assertEq(undefined != 5, true);

