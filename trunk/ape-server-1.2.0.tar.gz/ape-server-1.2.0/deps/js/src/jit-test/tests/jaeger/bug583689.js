function f() {
    if (-[]) delete y
}
for (c in [0, 0, 0, 0]) {
    new f
}

