var n = -2147483648;
assertEq(-n, 2147483648);
