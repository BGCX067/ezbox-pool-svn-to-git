const X = 12;

eval("switch (X) { case X: print(); }");

/* Don't assert. */

