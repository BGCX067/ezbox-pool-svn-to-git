let c = (this != 4.2);

/* Don't assert. */
