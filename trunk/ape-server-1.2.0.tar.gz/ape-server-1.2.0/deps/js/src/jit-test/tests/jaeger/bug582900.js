// |jit-test| error: ReferenceError

[].x >>= a | 0
