/* Test that NaN does not trigger js_InitMathClass & constants while parsing. */
var NaN

var x = 2;

