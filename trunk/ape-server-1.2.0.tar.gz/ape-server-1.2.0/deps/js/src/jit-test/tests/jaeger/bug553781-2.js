(function() {
  do {
    try {
      return
    }
    catch(x if (c)) {
      return
    } (x)
  } while (x)
})()

/* Don't assert. */

