for (let c in []) {
    c << c++
}

/* Don't assert. */

