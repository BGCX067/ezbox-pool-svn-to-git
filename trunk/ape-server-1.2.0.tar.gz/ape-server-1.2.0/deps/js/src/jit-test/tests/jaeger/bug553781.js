(function () {
    try {
        return
    } catch (x if i) {
        return
    }
    for (z in []);
})()

/* Don't assert */

