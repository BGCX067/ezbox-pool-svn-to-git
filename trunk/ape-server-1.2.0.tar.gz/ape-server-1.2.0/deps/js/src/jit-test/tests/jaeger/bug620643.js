var a = new Int32Array(); +(a[0]={});
