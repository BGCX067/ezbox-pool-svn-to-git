function f(a) {
  function a() {
  }
}

/* Don't assert on JOF_NAME test in BindNameToSlot(). */

