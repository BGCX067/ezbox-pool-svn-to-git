(function () {
    x ^ x++
    var x
})()

/* Don't assert. */

