x = this.__defineSetter__("x", function(z) function() { z })
